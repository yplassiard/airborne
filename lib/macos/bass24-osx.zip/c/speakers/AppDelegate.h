/*
	BASS multi-speaker example
	Copyright (c) 2003-2021 Un4seen Developments Ltd.
*/

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end

