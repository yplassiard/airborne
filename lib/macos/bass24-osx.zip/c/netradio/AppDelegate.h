/*
 	BASS internet radio example
 	Copyright (c) 2002-2021 Un4seen Developments Ltd.
*/

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end

